# The Power Workspace Contract

> Version: 1 · This is the single source of truth for how a power session's workspace works.
> Every skill in the power suite complies with this file and must NOT restate its rules.
> Foreign agents (any AI, any platform) are expected to follow it too — it is written to be
> understood without any special tooling.

## Why this contract exists

A power session outlives any single conversation. Contexts get cleared, sessions end,
different agents take over. The only thing that reliably survives is the filesystem.
So the contract's purpose is simple: **make the files tell the whole story.** If every
agent writes state to disk in the moment it happens, then any agent — tomorrow, next
week, or a completely different AI — can pick up the mission exactly where it stopped.

Three properties make that work:

1. **Crash-safe journaling** — state is written in the same turn it happens, never held
   only in memory. A context loss at any point loses at most the current action, never
   the mission history.
2. **One writer per file** — every file has exactly one owner that writes it. Everyone
   else reads. No merge conflicts, no clobbered state.
3. **Verify-don't-trust** — status text is a claim; the disk is the truth. Nothing is
   ever marked done because a report said so.

## Workspace layout

```
<workspace>/                        # the project root
├── worklog.md                      # PERMANENT journal at root — the beacon
└── .power/
    ├── README.md                   # bootstrap map for any agent (written once at init)
    ├── active/                     # the live mission — moved on archive
    │   ├── state.md                # the standing brief (stage pointer, now/next)
    │   ├── mission.md              # what & why (grill's output)
    │   ├── context/
    │   │   └── research.md         # findings & verdicts (scout's output)
    │   ├── tasks.md                # the board (planner's output, executor updates status)
    │   └── workflow.md             # the execution recipe (workflow's output)
    └── sessions/
        ├── 001-<slug>/             # archived missions, read-only
        └── 002-.../
```

`.power/` starts with a dot, so it is hidden in many listings. That is why `worklog.md`
lives at the root with a **beacon header** at the very top — it is the visible pointer
into the hidden state. Never remove the beacon while a session is active.

## File ownership (one writer per file)

| File | Sole writer | Everyone else |
|---|---|---|
| `worklog.md` | executor + power + dispatched subagents (append only) | may read, never rewrite or delete |
| `.power/README.md` | power (at init / archive) | read-only |
| `.power/active/state.md` | power + executor (checkpoint fields) | read-only |
| `.power/active/mission.md` | power-grill | read-only (planner/executor add decisions-log rows via power) |
| `.power/active/context/research.md` | power-scout | read-only |
| `.power/active/tasks.md` | power-planner creates; power-executor updates Status/Notes | read-only |
| `.power/active/workflow.md` | power-workflow | read-only |
| `.power/sessions/**` | NOBODY (read-only archive) | read-only, always |

## Status vocabulary (tasks.md)

`todo` → `in_progress` → `done` · side exits: `blocked`, `cancelled`

- `todo` — not started, deps unsatisfied or queued
- `in_progress` — a subagent is dispatched or work is underway (Notes record `attempt n/3`)
- `done` — verified against acceptance criteria on disk (evidence in worklog)
- `blocked` — cannot proceed; reason in Notes; triggers a loop-back decision
- `cancelled` — dropped with explicit user approval (never silently)

Legal transitions: `todo→in_progress→done` · `in_progress→blocked→(loop-back)→todo` ·
any→`cancelled` (user approval only). `done` is final for the session — reopened tasks
get a NEW id in a re-plan, never a silently edited old one.

## Task ID scheme

Hierarchical — mirror the harness's subagent ID convention when it has one:

```
1            # top-level task
1-a, 1-b     # subtasks of 1
2            # next top-level task
```

The dispatch Task ID equals the tasks.md ID. IDs are never reused after a re-plan;
new work gets fresh IDs.

## worklog.md format

Top of file (the beacon, maintained by power):

```
> ⚡ POWER BEACON: active session 003 (<slug>) — state: .power/active/state.md — rules: .power/README.md
> Agents: append below. Append-only. One writer per file. Verify before continuing.
```

When no session is active the beacon line reads:
`> ⚡ POWER BEACON: no active power session. If .power/active/state.md exists, read it first.`

Each mission starts its own section:

```
## Power Session 003 — <slug>
```

Each unit of work appends exactly one entry in this format:

```
---
Task ID: <tasks.md id, or "power" for orchestrator actions>
Agent: <who did it: main / subagent-N / power>
Task: <one-line what>

Work Log:
- <what was done, concretely>
- <decisions made and why>

Stage Summary:
- <result: artifacts produced (paths), verification evidence, next step>
```

Append-only means: never rewrite, reorder, or delete entries. Correcting the record is
done by a NEW entry that says what was wrong.

## The four rules for any agent in this workspace

1. **Append-only worklog** — add entries, never edit history.
2. **One writer per file** — check the ownership table before writing anything.
3. **`sessions/` is read-only** — archives are history, not working data.
4. **Verify before continuing** — re-check acceptance criteria against artifacts on disk
   before trusting any status, including your own predecessor's.

## Host capabilities (role names, not products)

The suite never names a specific tool — harnesses differ. It refers to capabilities by
role, and maps each role to the harness's actual tool ONCE at session start (power
records the mapping in `.power/README.md`):

| Role | Meaning | Fallback if the harness lacks it |
|---|---|---|
| **question tool** | asks the user batched questions, each with 3–4 concrete options and exactly one recommended default | ask the same questions in plain conversation, one round at a time |
| **web search** | searches the web for facts, libraries, standards | ask the user, or proceed on recorded assumptions (gap documented in research.md) |
| **page reader** | fetches and extracts one web page's content | work from search snippets only; mark such findings `partial` |
| **subagent dispatch** | runs a stateless child agent with a self-contained prompt, awaits one report | execute the task inline yourself — verification rules still apply in full |
| **deliverables directory** | where final user-facing outputs belong | the harness's standard output location, agreed at init and written into state.md |

Whenever a fallback is used, note it once in the worklog ("no subagents — running
inline") so successors know the session runs degraded. The contract's own rules never
change with the harness.

## Deliverables

All user-facing deliverables go to the harness's **deliverables directory** (§Host
capabilities) with descriptive filenames. tasks.md acceptance criteria reference these
exact paths so verification is a filesystem check, not a judgment call.

## Ceremony budget

Power's pipeline is for multi-step work. Trivial requests (single-step, clear intent,
one tool chain) are handled directly with no scaffolding. When in doubt, prefer the
pipeline for anything that will take more than a few minutes or produce files a future
session must find.

Mission intensity (`fast` / `standard` / `deep`) is stamped in mission.md's header
at init and locked for the mission. It sizes depth — question counts, research
breadth, verification quickness. It is dial-invariant at contract level: every rule
in this file applies identically at all three settings.

## Sessions & archiving

- Sessions are numbered `001`, `002`, … zero-padded, in `.power/sessions/`.
- Only ONE active session exists (`.power/active/`).
- Archive = move `active/` → `sessions/NNN-<slug>/` after the user approves the wrap
  report, plus a snapshot copy of `worklog.md` into the session folder. Details:
  `power/references/state-machine.md` §Archive.

## Versioning & language

- `contract-version: 1` is stamped in each mission.md header. If a workspace shows a
  different version, power warns and asks before proceeding (no silent migration).
- All workspace files are written in the language of the conversation.

## Rules for stage skills (pipeline-only)

`power-grill`, `power-scout`, `power-planner`, `power-workflow`, `power-executor` run
ONLY inside the pipeline that `power` drives. If invoked standalone they refuse and
point the user to `power`. The two exceptions that work alone: `power` itself and
`power-resume` (a pure reading guide that writes nothing).
