# Session Init — Scaffolding Procedure & Templates

> Run by `power` when a NEW session starts (no `.power/active/state.md` exists).
> Templates below are written verbatim; fill only known fields and leave `<placeholders>`
> for unknowns — they get filled by later stages.

## Procedure

1. Determine the session number: list `.power/sessions/`, take the highest NNN, add 1
   (`001` when empty or folder missing).
2. Derive a slug from the user's request: 2–4 lowercase words, hyphenated
   (`ecommerce-checkout`, `q3-market-report`).
3. Create the tree:
   ```bash
   mkdir -p .power/active/context .power/sessions
   ```
4. Write `.power/README.md` from Template A, filling §Capability map: for each
   role, name the harness's actual tool, or `fallback` where it lacks one
   (contract.md §Host capabilities).
5. Write `.power/active/state.md` from Template B.
6. Write skeletons: `mission.md` (Template C), `context/research.md` (Template D),
   `tasks.md` (Template E), `workflow.md` (Template F).
7. Update root `worklog.md`: set the beacon line (Template G) and append the session
   header (Template H). If `worklog.md` does not exist, create it with beacon + header.
8. Journal the init action (one worklog entry, Task ID `power`).
9. Continue to stage 1 (grill).

---

## Template A — `.power/README.md`

```markdown
# Power Session Workspace

This workspace is managed by a **power session** — a resumable mission pipeline:
grill (clarify) → scout (research) → planner (tasks) → workflow (execution recipe)
→ executor (subagent task loop) → wrap (verify + archive).

## Map
- `active/state.md`    — START HERE: current stage, now/next, blockers
- `active/mission.md`  — goal, scope, done-definition, decision log
- `active/context/`    — research findings & verdicts
- `active/tasks.md`    — the task board with acceptance criteria
- `active/workflow.md` — how the tasks get executed
- `../worklog.md`      — permanent journal (beacon at top)

## Capability map (this harness)
| role | actual tool here | fallback in use? |
|---|---|---|
| question tool | <name or "fallback — plain conversation"> | |
| web search | <name or "fallback — ask user / assumptions"> | |
| page reader | <name or "fallback — snippets only"> | |
| subagent dispatch | <name or "fallback — run inline"> | |
| deliverables directory | <path> | — |

Filled once at init; re-checked whenever a different agent or harness resumes
(contract.md §Host capabilities).

## Reading order for a cold agent
1. `active/state.md` 2. `active/mission.md` 3. `active/tasks.md`
4. tail of `worklog.md` (~10 entries) — then you know the situation.

## Rules (binding on every agent, human or AI)
1. `worklog.md` is append-only — add entries, never edit history.
2. One writer per file — see the ownership table in
   `skills/power/references/contract.md` if the power suite is installed.
3. `sessions/` is read-only archive.
4. Verify before continuing — trust artifacts on disk, not status text.

## Re-entering the pipeline
Invoke `power` (it advances the state machine). If the power skills are not
installed, work from the files directly: they are self-describing.

## Sessions
- <NNN-slug>: <one-line result>          ← appended at each archive
```

## Template B — `.power/active/state.md`

```markdown
# Session State

contract-version: 1
session: <NNN>
slug: <slug>
stage: <grill|scout|planner|workflow|executor|wrap>
updated_at: <ISO timestamp>
owner-agent: <agent id or "unclaimed">
mission-one-liner: <filled by grill>

now: <current concrete action>
next: <what happens after>
blockers: []

in-flight:
  task_id: <id or none>
  dispatched_at: <ISO timestamp or —>
```

## Template C — `mission.md` skeleton

```markdown
# Mission <NNN> — <slug>

session: <NNN> · contract-version: 1 · autonomy: auto+interruptible · intensity: <fast|standard|deep — from the invocation; default standard>
language: <conversation language> · created: <date>

## Goal
<filled by grill>

## Background
<...>

## Scope-In
<...>

## Scope-Out
<...>

## Constraints
<...>

## Done-Definition
<!-- bulleted; each item verifiable on disk -->

## Success Criteria
<...>

## Decisions Log
| timestamp | decision | reason | source |

## Open Questions
| question | proposed assumption | status |
```

## Template D — `context/research.md` skeleton

```markdown
# Research — Mission <NNN>

session: <NNN> · progress: 0/<N> questions settled · searches: 0 · reads: 0

## Research Questions
| # | question | answered? |

## Findings
<filled by scout>

## Conventions & Standards
<...>

## Gaps & Unanswered
<...>

## Recommendation Summary
<...>
```

## Template E — `tasks.md` skeleton

```markdown
# Tasks — Mission <NNN>

plan-version: 1 · mission-ref: mission.md · updated: <date>

| ID | Task | Status | Deps | Acceptance | Notes |
|----|------|--------|------|------------|-------|

## Next-Up
<executor reads this first>

## Change Log
| plan-version | change | reason |
```

## Template F — `workflow.md` skeleton

```markdown
# Workflow — Mission <NNN>

playbook: <name> · fit: <why it fits> · source: tasks.md plan-version <n>

## Phases
| phase | tasks | verify | checkpoint |

## Dispatch Notes
<special needs, batching, capabilities to name>

## Risks
<...>
```

## Template G — beacon line (root `worklog.md`, top of file)

```
> ⚡ POWER BEACON: active session <NNN> (<slug>) — state: .power/active/state.md — rules: .power/README.md
> Agents: append below. Append-only. One writer per file. Verify before continuing.
```

## Template H — session header (appended to `worklog.md`)

```
## Power Session <NNN> — <slug>
```
