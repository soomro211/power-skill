# Coverage Checklist — Depth Scoring & Stopping Rules

> Decides how hard grill interrogates (adaptive depth, decision D2) and when to stop.

## The 12 coverage dimensions

| # | Dimension | Typically answered by |
|---|---|---|
| 1 | Goal (artifact noun, concrete) | A1, A4 |
| 2 | Outcome measure (what success looks like) | A3 |
| 3 | Audience & context of use | B1–B5 |
| 4 | Scope-in (core capabilities) | C1, A5 |
| 5 | Scope-out (explicit exclusions) | A6, C2 |
| 6 | Constraints (time/tech/budget/compat) | D1–D7 |
| 7 | Assets & facts on hand | E1–E4 |
| 8 | Data source & shape | C5, H3/H4 |
| 9 | Risks & must-never-happen | A4, D8, F1, F8 |
| 10 | Process prefs (autonomy, checkpoints, stop-triggers) | G1, G2, G7 |
| 11 | Deliverable format & destination | G3, G4 |
| 12 | Done-Definition (verifiable items) | synthesized from 1, 3, 5, 9 |

A dimension counts as **covered** only if the user's own words establish it — your
assumptions don't count. Mark each dimension covered / partial / missing while
listening; coverage is scored on the INITIAL request before round 1, then re-scored
after every round.

## Depth bands (score = dimensions covered by the initial ask)

| Score | Mode | Question budget |
|---|---|---|
| 0–5 | FULL | 16–28 questions, rounds of 4–6 (large or novel missions may run 6–7 rounds and use the full 28) |
| 6–8 | MEDIUM | 8–12 questions, rounds of 4 |
| 9+ | CONFIRM | 3–6 questions — verify what you think you heard, confirm assumptions |

Worked example: *"Build me a dashboard for my Shopify sales data"* — covers goal (1,
dashboard), audience (1, me), data source (8, Shopify) → score 3 → FULL mode.

## Intensity dial (mission.md header — fixed at init)

| intensity | Effect on bands |
|---|---|
| `fast` | CONFIRM band forced (3–6 questions) regardless of score — speed is the point. Uncovered dimensions do NOT become rounds of questions; they go straight to the assumption protocol, loudly logged. |
| `standard` (or absent) | Self-scored bands exactly as the table above. |
| `deep` | FULL band forced (≥16 questions) even for a clear request. If the request looks trivial, power confirms with the user before running it. |

The dial changes how MANY questions grill asks — never HOW it asks them (the option
quality bar is identical) and never the journaling rules.

## Stopping rules — stop asking when ANY holds

1. **Coverage green**: all 12 dimensions covered or explicitly waived.
2. **Fatigue signals**: one-word answers, "whatever you think", "just go", repeated
   "same as before". Then: fill remaining gaps from the assumption protocol and move on.
3. **User says go**: the user's explicit stop outranks the checklist.
4. **Budget exhausted**: total questions reached the band's ceiling. Never exceed 28
   questions in one mission without the user asking to continue. Within FULL mode,
   a high round count is NOT a stopping reason by itself — big tasks legitimately
   need many rounds; stop only on these four rules. Conflict re-asks (§Conflicts)
   are EXEMPT from this budget.

Remaining missing dimensions → assumption protocol (below), never silent gaps.

## Assumption protocol

For each still-missing dimension:

1. Choose a sensible default (question-bank recommendations are the defaults).
2. Record it in mission.md Open Questions: `| question | proposed assumption | open |`
3. Mention the assumption to the user in one line at grill exit ("assuming desktop-only
   use — flag if wrong"). Auto autonomy means the pipeline proceeds on the assumption;
   the record keeps it honest and reversible.

## Conflicts — detection & resolution

Any answer can contradict an earlier one, the original request (quoted verbatim in
Background), or a hard Constraint. Grill is the only stage that can catch these while
they are still cheap — so it checks twice:

1. **Per-round micro-scan** — after journaling each round, compare ONLY the new
   answers against everything already journaled + the Background request.
2. **Final sweep** — a full pass over the complete draft before mission.md is stamped
   (blocking gate: no open direct contradiction may survive into the mission).

### Taxonomy (2 severities)

| Type | Looks like | Severity |
|---|---|---|
| Direct contradiction | answer B excludes answer A ("free tools only" ↔ "use the paid API") | **blocking** |
| Request-vs-answer | the original request says X, an answer says not-X | **blocking** |
| Tension | both can be true but the trade-off is unacknowledged ("ship this week" + "test on 3 platforms") | noted → risk |
| Drift | a later answer quietly narrows or widens earlier scope | noted → risk |

Tension/drift pass through: they land in Constraints or Open Questions as recorded
risks. Blocking conflicts MUST be resolved before mission.md is stamped.

### Resolution protocol

1. **Re-ask (batched, once)**: all open conflicts go into ONE micro-round — each
   conflict as its own question with options = answer A / answer B / hybrid, one
   recommended, same quality bar as every grill question. Conflict re-asks are
   **EXEMPT from the question ceiling** (the 16–28 budget governs planned questions;
   fixing contradictions is not planning depth). If the re-ask still leaves a
   blocking conflict, resolve it via the assumption protocol and record it
   `resolved-assumption` — never loop the user indefinitely.
2. **Supersede is legal**: "the new one wins" records as `superseded`, not a conflict
   — changing your mind is not a bug.
3. **Anti-recency rule**: never auto-resolve in favor of the LATER answer just
   because it is newer — the Goal + Done-Definition decide.
4. **Auto mode / minor stakes**: grill picks what best serves Goal + Done-Definition,
   logs the assumption, announces it at exit.
5. **Ledger**: every conflict gets a §Conflicts row in mission.md; consequential
   resolutions also get a Decisions Log row (`conflict <#> resolved: …`).

Only surface conflicts that would change Goal, Scope, Constraints, Done-Definition,
or task shape — stylistic wobbles are noise. Phrase neutrally ("round 1 chose X,
round 3 chose Y — which wins?"), never gotcha-framing.

## Round composition

Per round pick 4–6 questions: first from dimensions marked missing that BLOCK other
decisions (goal, scope, constraints), then highest-impact remaining. Category H
questions replace generic ones whenever the domain is known. Ask via the **question
tool** (contract.md §Host capabilities; plain conversation if none): each question
gets 3–4 concrete options, exactly one recommended,
multiSelect where choices genuinely co-exist (e.g., deliverable formats).

## After each round

Re-score coverage → journal the round's Q&A into mission.md draft sections + Decisions
Log immediately (crash-safe: a context loss mid-grill resumes from mission.md, see
contract.md §Journaling) → conflict micro-scan (§Conflicts) → next round or exit.
