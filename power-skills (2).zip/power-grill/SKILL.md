---
name: power-grill
description: Stage 1 of the power pipeline — requirements interrogation. Do not invoke standalone; power runs it automatically at session start. Produces mission.md by questioning the user adaptively — a full 16–28 question interrogation in rounds of 4–6 for vague requests (large or novel missions may need all 28), or a 3–6 question confirmation pass for clear ones — every question offering concrete options with a recommended default, answers journaled to disk each round, answer conflicts detected and resolved before the mission is finalized, and depth honoring the mission's intensity dial (fast/standard/deep).
---

# power-grill — interrogate, then write the mission

> Pipeline-only: this skill runs as stage 1 of `power`. If invoked standalone, refuse
> and tell the user to invoke `power` instead. In re-grill mode (sent back by the
> executor) follow §Re-grill at the end.

You turn a fuzzy human request into `mission.md` — the document every later stage
trusts instead of re-asking. Two things make grill valuable rather than annoying:
**adaptive depth** (match the interrogation to how vague the request actually is) and
**journaling every answer to disk immediately** (so a context loss never eats the
user's answers).

## Inputs

- The user's request (verbatim — quote it in Background).
- Any existing workspace files (a resume, an old mission, a repo).
- Re-grill: a specific question or ambiguity handed back by the executor.

## Step 1 — Score coverage

Read `references/coverage.md`. Score the 12 dimensions against the user's initial
request (their words only, not your assumptions) → FULL / MEDIUM / CONFIRM mode and
the question budget. State the mode in one line: "vague request → full grill (target
16–28 questions; large missions may use all 28)".

Intensity dial override: if the invocation carried `power fast|deep|standard` (it is
recorded as `intensity:` in the mission.md header), the dial OVERRIDES self-scoring —
`fast` forces the CONFIRM band (uncovered dimensions become loudly-logged assumptions,
not questions), `deep` forces FULL with ≥16 questions even for a clear request,
`standard` or absent keeps the self-scored bands. The dial is fixed for the whole
mission.

## Step 2 — Interrogate in rounds

Per round (4–6 questions via the **question tool** — contract.md §Host capabilities;
plain conversation works if the harness has no such tool):

1. Pick questions from `references/question-bank.md` — uncovered dimensions first,
   blocking dimensions (goal, scope, constraints) before nice-to-know ones; category H
   replaces generics when the domain is obvious.
2. Every question: 3–4 CONCRETE options (names, numbers, examples — never "simple/
   professional" vagueness) and exactly one recommended default. The recommendation
   is what you would pick given everything said so far — say why in the question text
   when the reason isn't obvious.
3. multiSelect only where choices genuinely co-exist (deliverable formats, features).
4. **Journal immediately after each round** (this is the crash-safe rule from
   `skills/power/references/contract.md`): append answers into the mission.md draft
   sections they belong to, and one Decisions Log row per consequential choice.
   Do not batch journaling to the end.
5. **Conflict micro-scan** (`references/coverage.md` §Conflicts): compare this
   round's answers against ALL earlier journaled answers AND the verbatim request
   quoted in Background. A direct contradiction or request-vs-answer hit is resolved
   NOW per the conflict protocol — its re-ask round is exempt from the ceiling.
6. Re-score coverage → next round or stop (stopping rules in coverage.md).

Tone: brisk and structured, not an interrogation montage. Groups of related questions,
clear options, zero filler.

## Step 3 — Write mission.md

Finalize `.power/active/mission.md` exactly per `references/mission-format.md`:

- Done-Definition: 3–7 bullets, each verifiable on disk (reject vague ones).
- Scope-Out explicitly records what the user excluded or never requested.
- Every unanswered dimension lands in Open Questions with a proposed assumption
  (coverage.md §Assumption protocol) — auto autonomy means the pipeline proceeds on
  assumptions, but they are recorded and announced.
- **Final conflict sweep (blocking gate)**: re-scan the complete draft (all answers
  + the Background request) per coverage.md §Conflicts. mission.md is never stamped
  with an open blocking conflict: run ONE batched conflict re-ask round; if a
  conflict survives even that, resolve it via the assumption protocol, mark it
  `resolved-assumption` in §Conflicts, and announce it at exit.
- Stamp the header (session, contract-version: 1, autonomy, language, intensity).

## Step 4 — Exit

1. Announce the assumptions line ("assuming X — flag if wrong") plus any conflict
   resolutions that used the assumption protocol.
2. Report in ≤3 lines: mission one-liner + Done-Definition count + open questions count.
3. Hand back to power: state.md `stage: scout`, journal the exit. Power prints the
   stage-end notice.

## Re-grill (loop-back from executor)

The executor only sends back SPECIFIC ambiguities ("task 4-b assumes invoice numbering
format — no decision exists"). Then:

- Ask ONLY the missing question(s) — one round, options + recommendation as usual.
- Append answers: mission.md relevant section + Decisions Log row
  (`loop-back grill←executor` reason) + resolve the originating Open Question row.
- Never rewrite Goal/Scope in re-grill — scope changes belong to planner re-plans.
- Conflicts surfaced by a loop-back resolve through the same §Conflicts ledger
  (source: `loop-back`).

## Question quality bar (the difference between grill and a form)

- Bad option set: `Simple / Professional / Advanced` (adjectives — means nothing).
- Good option set: `single HTML page` / `Next.js app with auth` / `static generator,
  deploy anywhere` (the user can SEE choosing each).
- Bad question: "Any constraints?" Good question: "Must this run without internet
  access, or are cloud APIs fine?"
- If your options make the user type a novel, your options are wrong; if they can only
  answer "other", your options missed the space.
