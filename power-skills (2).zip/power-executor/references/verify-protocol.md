# Verify Protocol — On-Disk Verification & Failure Taxonomy

> The executor's spine. A task is done when DISK EVIDENCE says so — never when the
> subagent's report says so. Subagents are optimistic by nature; verification is the
> pipeline's immune system.

## The verification ladder (run in order; stop at first fail)

1. **Existence** — does each declared artifact exist at its stated path?
   (`exists:` criteria + RETURN's artifacts list.) Missing → fail immediately.
2. **Content** — does each artifact contain what its criteria demand?
   (`contains:` / observable-behavior criteria.) Check literally: a criterion saying
   "monthly series Jan–Jun" means you LOOK for the six months, not for "a chart".
3. **Function** — when applicable, RUN it: the command passes, the app starts, the
   document opens/renders, the test suite exits green. (`passes:` criteria.)
   Save command output as evidence — it goes in the worklog entry.
4. **Evidence recording** — append per-criterion lines to the worklog Stage Summary:

```
- [pass] exists: download/sales-chart.png (14.2 kB)
- [pass] contains: monthly series Jan–Jun, axis labels, source note
- [pass] passes: python verify_chart.py → exit 0
- [fail] contains: source note missing → CONTENT-GAP
```

## Depth by intensity (mission.md header — fixed at init)

| intensity | Depth |
|---|---|
| `fast` | **quick verify** — ONE combined pass: existence on every declared artifact + spot-check of the most load-bearing acceptance criteria; evidence marked `quick-verified`. |
| `standard` | **normal verify** — the full ladder, every criterion, every rung. |
| `deep` | **normal verify** — identical to standard. Deep buys more questions, research, and planning — NOT harder verification. |

At every depth: the RETURN alone is never a pass, no criterion is silently
downgraded, partial passes are fails. Quick trades COVERAGE of checks, never honesty.

## Fail taxonomy (classify before reacting)

| Type | Meaning | Reaction |
|---|---|---|
| RETRYABLE | environmental/transient — network blip, tool hiccup, OOM | re-dispatch immediately, same prompt + note ("attempt 1 failed: timeout on install") |
| CONTENT-GAP | work is real but misses criteria | re-dispatch with PREVIOUS ATTEMPT FAILED addendum (dispatch-protocol), counter `attempt n/3` |
| SPEC-GAP | criteria can't be judged — mission never decided something (format? naming? tone?) | STOP the loop; route to grill (targeted re-clarify); this is decision debt, not worker failure |
| PLAN-GAP | the task as planned is wrong, impossible, or pointless (approach invalid, dependency dead, criterion unsatisfiable) | STOP the loop; route to planner (re-plan) with evidence |

Classification test: ask *"could a perfect worker have passed this task as written?"*
Yes-but-didn't → RETRYABLE/CONTENT-GAP. No → SPEC-GAP/PLAN-GAP. Workers who could
never succeed should never burn retries.

## Attempt accounting

- Counter lives in the tasks.md Notes cell: `attempt n/3` — persisted, crash-safe.
- Retry only on RETRYABLE/CONTENT-GAP. SPEC-GAP/PLAN-GAP never consume retries —
  they leave the loop immediately.
- 3 failed attempts on one task → stop → loop-back to planner with all evidence.
- Loop-back budget: 3 per mission (state-machine.md); beyond that, surface to user.

## Honesty rules

- Never mark `done` from the subagent's RETURN alone — the RETURN is a claim; the
  ladder is the check.
- Never downgrade a criterion to make a pass ("close enough" is a decision for the
  user at wrap, recorded as a waived criterion — not a silent edit).
- Partial passes are fails: all criteria or no done.
- If YOU (the executor) cannot run a functional check (no environment for it), record
  that explicitly in evidence as `unverified-functional` and let wrap decide — never
  fake a pass.
