---
name: power-planner
description: Stage 3 of the power pipeline — mission decomposition. Do not invoke standalone; power runs it automatically. Reads mission.md and context/research.md, decomposes the mission into a tasks.md board with hierarchical IDs, minimal dependencies, and verifiable acceptance criteria per task; re-plans safely with version bumps when scope changes or executor loop-backs arrive.
---

# power-planner — turn the mission into a buildable board

> Pipeline-only: runs as stage 3 of `power`. If invoked standalone, refuse and point
> to `power`. In re-plan mode (sent back by power after a scope change or executor
> 3-strike) follow §Re-plan at the end.

The board is the pipeline's contract with reality: the executor follows it
mechanically, wrap verifies against it, and any cold agent can reconstruct the
mission from it. Plan so a stranger could execute — because often, one will.

## Inputs

- `.power/active/mission.md` — especially Done-Definition and Constraints.
- `.power/active/context/research.md` — scout's USE/ADAPT/BUILD verdicts and Gaps.
- Current tasks.md (skeleton or, in re-plan, the live board).

## Step 1 — Decompose from Done-Definition backwards

Work the way wrap will verify: each Done-Definition item must be produced by at least
one task. Build the task set so the criteria are met, then add only what's needed to
make those tasks executable (setup, data prep, scaffolding). The mission is the
Done-Definition — not an opportunity to build everything interesting.

Sort each mission item into shape from research verdicts:

- **USE** → the task is "wire in / configure <premade thing>" + a verification task.
- **ADAPT** → integration task + customization tasks.
- **BUILD** → implementation tasks (scaffold → implement → verify).
- **Gap** (unanswered research) → treat as assumption; say so in the task's Notes.

## Step 2 — Size and shape tasks

Apply `references/tasks-format.md` §Task sizing: one task = one session-chunk, one
output, independently verifiable. Mark micro-tasks `batch: true` so the workflow may
group them into a single dispatch. Reject any task whose acceptance needs two features
at once — split it. Healthy range 5–15 tasks.

Intensity sizing (mission.md header): `fast` → tag every task `MVP` / `v1.1` /
`nice-to-have` (the cutline) so scope can shrink without a re-plan. `deep` → add a
one-line risk note to each top-level task's Notes (what most likely breaks it).
`standard` → neither extra.

Write each row in the good-task shape:

```
Task: <what> | Output: <what exists after> | Accept: <how to verify on disk>
```

## Step 3 — Dependencies & Next-Up

- Minimal deps only; kill chains deeper than 4 (they hide parallelism or granularity
  errors). Note: executor v1 dispatches sequentially in dependency order anyway —
  deps exist for CORRECTNESS of order, not speed.
- Fill §Next-Up: the ordered runnable list (deps satisfied), executor's entry point.
- Flag the critical path mentally; if it's longer than ~5 tasks, re-examine sizing.

## Step 4 — Sanity checks before exit

1. Every Done-Definition item ↔ ≥1 task (write the mapping in Notes of the task).
2. Every Constraint respected by the plan (offline, budget, stack locks — check each).
3. Every Open Question with a proposed assumption appears in the Notes of the task
   that relies on it.
4. Deliverable paths referenced in acceptance criteria are concrete
   (files in the deliverables directory, named — e.g. `<deliverables>/<name>`).
5. Nothing in the board contradicts research verdicts.

## Step 5 — Exit

Write tasks.md per `references/tasks-format.md` (plan-version 1, Change Log row
"initial plan"). Report ≤3 lines: task count, critical path, assumptions carried.
Hand back to power: state.md `stage: workflow`, journal the exit.

## Re-plan (loop-back / scope change)

You arrive with either (a) failure evidence from the executor (3 strikes on task N)
or (b) a scope-change decision from power. Follow `references/tasks-format.md`
§Re-plan rules exactly:

- History is untouchable (done/in_progress rows keep IDs+statuses).
- New work gets fresh IDs; superseded rows are `cancelled` with replacement pointers.
- plan-version bump + Change Log row + mission.md Decisions Log row.
- Diagnose BEFORE restructuring: was the task wrong (bad cut), the criterion wrong
  (unverifiable), or the approach wrong (research missed something)? Fix the CLASS of
  problem, not just the instance — the same failure in three sibling tasks means the
  plan, not the task, is wrong.
- If the fix requires a new external fact → say so explicitly so power sends scout
  top-up before execution resumes.
