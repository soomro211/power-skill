# The State Machine — Stages, Transitions, Loop-backs, Wrap

> How `power` drives a session. The stage pointer lives in `.power/active/state.md`
> (`stage:` field). Every transition updates `state.md` and journals to `worklog.md`.

## Stage table

| Stage | Skill | Entry when | Reads | Writes | Exit when | Next |
|---|---|---|---|---|---|---|
| grill | power-grill | mission.md incomplete/absent | user, existing files | mission.md | Done-Definition verifiable; coverage green (or assumptions logged) | scout |
| scout | power-scout | mission.md complete | mission.md, web | context/research.md | research questions answered or budget spent, gaps recorded | planner |
| planner | power-planner | research done (or gaps known) | mission.md, research.md | tasks.md | every Done-Definition item maps to ≥1 task with acceptance criteria | workflow |
| workflow | power-workflow | tasks.md complete | tasks.md, mission.md | workflow.md | every task mapped to a phase; verify steps set | executor |
| executor | power-executor | workflow.md complete | workflow.md, tasks.md | deliverables, worklog.md, state.md, task statuses | no ready tasks remain; evidence present for all done | wrap |
| wrap | power | executor finished | everything | mission report, archive | user approves → archived | (session ends) |

## Transition procedure (per stage)

1. Update `state.md`: `stage: <next>`, `now`, `next`, `updated_at`.
2. Journal a worklog entry (Task ID `power`) noting the transition and the artifact
   that justified it.
3. Print the stage-end notice: `— stage <name> done · say stop to change course · continuing —`
4. Invoke the next stage skill and follow its SKILL.md.

## Loop-back edges (auto + logged)

Loop-backs keep the pipeline honest without user babysitting. Each one is a TARGETED
top-up, never a full stage redo.

| Edge | Trigger | Procedure |
|---|---|---|
| executor → planner | 3 failed verification attempts on the same task (retry counter in tasks.md Notes) | hand planner the failure evidence; planner re-plans from the failure point (new task IDs, plan-version bump) |
| executor → grill | task cannot proceed: a needed decision exists in neither mission.md nor user's answers (ambiguity) | grill asks ONLY the missing question(s), appends answer to mission.md, resolves the open question |
| executor → scout | task needs an external fact that research.md lacks | scout answers that specific question within a small budget (≤2 searches), appends finding |
| planner → scout | decomposition blocked: mission assumes facts nobody established | scout top-up as above |

Every loop-back appends a row to mission.md Decisions Log:
`| <timestamp> | loop-back <from>→<to> | <one-line reason> | <stage> |`
and a worklog entry. After the top-up returns, the requesting stage re-verifies and
resumes. Loop-backs are limited to 3 per mission — beyond that, stop and surface the
situation to the user (the mission may be under-specified at a deeper level).

## Interrupt semantics

- **Atomic action** = one dispatch+verification cycle (executor) or one Q&A round
  (grill). Interrupts land on atomic boundaries only.
- On user "stop": finish the current atomic action, journal it, set `state.md`
  (`now: paused — <reason>`), and await the user. Do not start new work.
- On new user input mid-mission, classify:
  1. **Scope change** (relates to the mission goal) → planner re-plan; log decision.
  2. **Unrelated task** → ask: archive current session first, park it, or decline?
     Never interleave two missions.
  3. **Plain question** → answer; no state change.

## Resume procedure (power re-entry)

1. Read `.power/active/state.md`. If missing → normal new-session flow.
2. Check `owner-agent` / `updated_at` — if another agent claimed recently and may be
   active, say so and ask before claiming (`owner-agent: <me>`).
3. If `in-flight.task_id` is set → **verify-don't-trust**: check the task's acceptance
   criteria against disk. Completed → journal + mark done; partial → count as a failed
   attempt, note evidence; no trace → re-dispatch fresh.
4. Continue at `stage:` per the stage table. Summarize to the user in 2–3 lines what
   you resumed and why.

## Wrap — completeness checklist (all must hold)

- [ ] Every task in tasks.md is `done`, or `cancelled` with explicit user approval
- [ ] Every `done` task has verification evidence in worklog.md (per-criterion)
- [ ] Deliverables exist at the paths referenced in acceptance criteria
      (`/home/z/my-project/download/`)
- [ ] Each mission.md Done-Definition item individually checked against reality
- [ ] Open Questions: resolved, or explicitly waived by the user
- [ ] No unresolved blockers

## Mission report (shown to user at wrap)

```markdown
# Mission Report — <NNN-slug>
**Goal:** <mission one-liner>
**Result:** <2–4 sentences: what exists now>
**Deliverables:** <paths in download/>
**Tasks:** X/Y done · <cancellations, if any>
**Decisions of note:** <top 3 from the log>
**Carry-over:** <open questions waived / future ideas>
```

Then ask for approval. **This is the only hard approval gate in the pipeline.**

## Archive procedure (after user approval)

1. `mv .power/active .power/sessions/<NNN>-<slug>`
2. `cp worklog.md .power/sessions/<NNN>-<slug>/worklog-snapshot.md`
3. Update `.power/README.md` sessions list.
4. Set beacon line to the "no active power session" text (see contract.md).
5. Journal: `Session <NNN> archived — workspace clean.`
6. Confirm to the user: next `power <task>` opens session NNN+1.

If the user does NOT approve: keep `active/` as-is, record objections in the Decisions
Log, and ask what to fix — loop back into the relevant stage instead.

## Status report (bare `power` / `power status`)

Read state.md + last ~5 worklog entries and print:

```
⚡ Session <NNN> (<slug>) · stage: <stage> · updated <when>
Progress: <x>/y tasks done · blockers: <n>
Now: <now> · Next: <next>
```

No session active → print that and offer to start one.
