# Dispatch Protocol — Subagent Prompting for the Supervisor Loop

> How the executor turns a tasks.md row into a subagent dispatch. Host subagents are
> STATELESS: they see only the prompt you send and the filesystem they open. Every
> prompt must therefore be self-contained — written for a smart stranger.

## The prompt template (fill every slot)

```markdown
## ROLE
You are a focused worker on task <ID> of a managed mission. Do THIS task well;
do not redesign the mission, re-plan, or touch unrelated files.

## CONTEXT (read these first, in order)
- Mission one-liner: <from state.md mission-one-liner>
- Task board row: <paste the FULL tasks.md row verbatim — ID, task, acceptance, notes>
- <relevant mission.md sections — e.g., Constraints if the task touches them>
- <relevant research.md finding(s) — the verdict this task builds on>
- Tail of worklog.md (last ~5 entries) — so you don't redo or contradict prior work

## TASK
<the tasks.md Task cell, verbatim>
Output: <the single clear output this task produces>
Acceptance (you must satisfy ALL):
<paste acceptance criteria verbatim from tasks.md>

## DELIVERABLES
- User-facing artifacts go to /home/z/my-project/download/<descriptive-name>
- Working files stay in the workspace where the task naturally puts them

## WORKLOG (mandatory, before you finish)
Append ONE entry to /home/z/my-project/worklog.md (do not modify existing content):
---
Task ID: <ID>
Agent: subagent-<ID>
Task: <one line>
Work Log:
- <what you did, concretely>
Stage Summary:
- <artifacts produced (paths) + anything the verifier must know>

## RESTRICTIONS
- Do NOT modify anything under .power/active/ except your own deliverable files
  if the task explicitly assigns them there.
- Do NOT delete or rewrite worklog entries. Append only.
- <task-specific constraint reminders: stack lock / offline / do-not-touch lists>

## SKILLS
<If the task type matches a host skill, load it first: e.g. fullstack-dev for web
apps, docx/pdf/xlsx/pptx for documents, web-search for lookups. Otherwise none.>

## RETURN (your final message back)
- status: complete | failed (with one-line reason)
- artifacts: <list of paths produced>
- evidence: <per acceptance criterion: how it is met / why not>
- deviations: <anything you had to do differently, and why>
```

## Dispatch mechanics

- **One dispatch per task** (default). `batch: true` micro-tasks share ONE dispatch:
  the TASK section lists each micro-task with its own criteria; one worklog entry
  covers the batch with per-criterion evidence.
- **Task ID** sent to the host Task tool = the tasks.md ID (matches the host's
  subagent Task-ID convention).
- **Sequential**: dispatch, await completion, verify, then next. Never two at once —
  the verification of task N decides what task N+1's prompt should know.
- Before dispatching: set tasks.md row → `in_progress` (Notes: `attempt n/3`), and
  state.md `in-flight: {task_id, dispatched_at}`. Crash-safety: if you die
  mid-dispatch, the next agent must see exactly what was in the air.

## Retry template addendum (attempt ≥2)

Insert above RETURN in the template:

```markdown
## PREVIOUS ATTEMPT FAILED
Attempt <n-1> failed verification:
<paste the failure evidence verbatim from verify-protocol>
Avoid: <specific mistakes to not repeat>
You may reuse: <partial artifacts that survived, with paths>
```

Attempt 3 is the last attempt — if it fails, stop the loop (SKILL.md §Loop-backs):
the problem is the plan or the spec, not the worker.

## Prompt hygiene

- Paste acceptance criteria VERBATIM — paraphrasing is how criteria drift.
- Context is budget: include the sections the task touches, not the whole mission.
- One line about the mission's tone-level ("internal tool, nobody reviews" vs
  "client-facing, polish matters") improves output shape more than long essays.
- If the dispatch needs a decision that isn't written anywhere — STOP. That is a
  spec-gap (verify-protocol taxonomy): route to grill, don't let the subagent guess.
