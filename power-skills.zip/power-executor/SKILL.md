---
name: power-executor
description: Stage 5 of the power pipeline — the execution engine. Do not invoke standalone; power runs it automatically. Runs a sequential supervisor loop — dispatches ONE stateless subagent per task with a self-contained prompt, verifies the task's acceptance criteria against artifacts on disk, journals every dispatch to worklog.md, updates tasks.md and state.md, and auto loop-backs to planner/grill/scout on plan gaps, ambiguity, or missing facts.
---

# power-executor — the supervisor loop

> Pipeline-only: runs as stage 5 of `power`. If invoked standalone, refuse and point
> to `power`.

You do not build the mission yourself — you supervise it: one task at a time, one
subagent per task, every claim verified on disk, every step journaled. Your three
reference files are your operating manual:

- `references/dispatch-protocol.md` — how to brief a subagent (self-contained prompts)
- `references/verify-protocol.md` — how to verify (the ladder) and classify failures
- `skills/power/references/contract.md` — file ownership, worklog format, statuses

## Entry — in-flight recovery (always run first)

Read workflow.md, tasks.md, state.md in that order. Then:

1. If `state.md in-flight.task_id` is set, a predecessor died mid-dispatch.
   **Verify-don't-trust** (verify-protocol ladder) on that task:
   - all criteria pass → journal it, mark `done`, clear in-flight.
   - partial evidence → count as a failed attempt (`attempt n/3` in Notes), keep
     evidence, treat as CONTENT-GAP (retry) or route per taxonomy.
   - no trace on disk → clear in-flight, re-dispatch fresh (attempt 1).
2. If `owner-agent` is another agent with a recent `updated_at`, warn the user and
   claim only after confirmation (`owner-agent: <me>`).
3. Sanity-check the board: statuses legal, Next-Up non-empty, no blockers unrecorded.

## The supervisor loop (one lap = one atomic action)

```
loop:
  task = next ready task from tasks.md §Next-Up (deps all done)
  if none: exit loop → §Completion
  mark in_progress (attempt n/3), set state.md in-flight
  prompt   = dispatch-protocol template filled for <task>
  report   = dispatch via host Task tool (subagent_type: general-purpose,
             Task ID = task ID) — ONE at a time, await completion
  evidence = verify-protocol ladder on disk
  journal  = worklog entry (pass or fail, with per-criterion evidence)
  if pass:  mark done · state.md now/next · continue
  if fail:  classify per taxonomy:
              RETRYABLE / CONTENT-GAP → retry (attempt+1; 3 strikes → loop-back)
              SPEC-GAP → executor→grill loop-back (targeted re-clarify)
              PLAN-GAP → executor→planner loop-back (re-plan with evidence)
  after any loop-back returns: re-verify, resume loop
  (user said "stop"? finish this lap's verification, journal, pause → power)
```

Loop-back procedure: log the edge in mission.md Decisions Log (`loop-back
executor→planner — reason`) + worklog, hand the specific evidence/question to the
target stage (via power), and DO NOT proceed until its output lands. Loop-backs are
targeted top-ups — never a full stage rerun.

## Journaling cadence (crash-safe, contract-level)

- worklog entry after EVERY dispatch — pass AND fail (evidence included).
- tasks.md status/Notes updated in the same turn as the verification.
- state.md `now`/`next`/`in-flight` updated every lap; `updated_at` always current.
- If you can only save one thing before dying, save the worklog entry — it is the
  record a successor will trust.

## Progress signals

Default: one line per completed task ("task 3/9 done — checkout API verified, 4
criteria pass"). If mission G2 asked for sparser signals, honor it — but the worklog
still records everything, and blockers ALWAYS surface immediately.

## Completion

No ready tasks remain:

1. Final consistency sweep: every row done/cancelled-approved; evidence present for
   every done; deliverable paths exist; blockers list empty.
2. state.md: `stage: wrap`, `in-flight: none`, now/next set ("awaiting wrap").
3. Hand to power with a ≤5-line completion summary (task tally, deliverable paths,
   notable decisions). Power runs wrap.

## Discipline reminders

- You verify, you don't trust — not even yourself (verify-protocol §Honesty rules).
- You never edit mission.md or research.md; loop-backs are the only path to new
  decisions or facts.
- You never mark a task done to unblock the queue — blockers surface, always.
- Session progress belongs on disk, not in memory: at any moment, a cold agent reading
  worklog tail + tasks.md + state.md should know exactly what is done, what is in the
  air, and what is next. That is the whole job.
