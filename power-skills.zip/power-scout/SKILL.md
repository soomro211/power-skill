---
name: power-scout
description: Stage 2 of the power pipeline — research before planning. Do not invoke standalone; power runs it automatically. Reads mission.md, then searches the web for premade solutions, libraries, templates, industry standards, and prior art within a strict budget, writing context/research.md with a USE/ADAPT/BUILD verdict per finding so the planner plans on facts instead of guesses.
---

# power-scout — research the terrain before mapping it

> Pipeline-only: runs as stage 2 of `power`. If invoked standalone, refuse and point
> to `power`. In top-up mode (sent back by executor/planner for one missing fact),
> follow §Top-up at the end.

Planning without research builds what already exists for free. Scout's job is narrow
and disciplined: answer the mission's external unknowns, find premade solutions, and
end every finding with a verdict — **USE / ADAPT / BUILD** — so the planner writes
"wire in library X" tasks instead of reinventing wheels.

## Inputs

- `.power/active/mission.md` (goal, scope, constraints, open questions that research
  can answer — e.g., "facts only you can confirm" from grill).
- Nothing else is required; existing workspace files may inform search terms.

## Step 1 — Research questions (3–7)

Derive from the mission, prioritized:

1. **Premade solutions**: does a library/tool/template already do X? (Always ask when
   any scope-in item is a solved problem.)
2. **Standards & conventions**: how is this usually done in this domain? (Format
   conventions, file structures, API patterns.)
3. **Known pitfalls**: what breaks typically in this exact task type?
4. **Facts needed for sizing**: data volumes, API limits, version compatibility.
5. Mission-specific open questions research can settle.

Write all questions into research.md §Research Questions BEFORE searching — they are
the budget's unit of accounting.

## Step 2 — Search within budget (hard limit)

Defaults: **≤6 web searches and ≤6 page reads.** mission.md Constraints may override
(only upward with a recorded decision). When the budget is spent: stop, record what
remained unanswered in §Gaps — a documented gap beats a blown budget. (Rationale:
scout is a stage, not a research mission; an unbounded scout is the pipeline's
biggest latency tax.)

Use the host `web-search` skill to search and `web-reader` to extract promising pages.
Prefer primary sources for facts; note access dates.

## Step 3 — Verdict per finding

For each finding write source, ≤3-sentence summary, relevance, and a verdict:

- **USE** — fits as-is → planner writes integration tasks, not builds.
- **ADAPT** — close exists, extend/configure → integration + customization tasks.
- **BUILD** — nothing adequate → say what from-scratch work should reuse anyway.

No verdict, no finding. See `references/research-format.md` for exact format and the
top-up append convention.

## Step 4 — Journal incrementally

Write research.md after EACH question is settled (or exhausted), not once at the end.
Crash-safe rule (contract.md): a context loss mid-scout must leave usable findings on
disk. Keep the header budget line current (`s/6 searches, r/6 reads`).

## Step 5 — Exit

1. §Gaps complete: every unanswered question recorded with its planning impact.
2. §Recommendation Summary: ≤5 bullets planner must not miss.
3. Report in ≤3 lines: findings count, verdict mix, gap count.
4. Hand back to power: state.md `stage: planner`, journal the exit.

## Top-up (loop-back from executor/planner)

The requester arrives with ONE specific missing fact ("does library X support
streaming on version Y?"). Then:

- Budget for the top-up: **≤2 searches + ≤2 reads.**
- Append a single `FT<n>` finding per `references/research-format.md` §Top-up.
- Mark the originating research question answered.
- Do NOT re-research anything else, even if you notice adjacent gaps — note them in
  one line for the requester instead.

## Discipline reminders

- If the user already named prior art (grill E4), start there — never re-research what
  the user already knows; verify and verdict it.
- If research reveals the mission is really two missions, say it loudly in the
  Recommendation Summary and let power/planner handle the split decision.
- Zero findings is a valid outcome (well-trodden territory): record that the domain is
  standard, cite one conventions source, move on fast.
