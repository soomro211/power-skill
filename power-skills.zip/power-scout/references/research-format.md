# research.md — Format & Authoring Guide

> scout owns this file. planner reads it instead of re-searching. Every claim carries
> a source; every finding ends in a verdict. Undated, unsourced text does not belong
> here.

## Template

```markdown
# Research — Mission <NNN>

session: <NNN> · mission-ref: mission.md · budget used: <s>/6 searches, <r>/6 reads
researched: <date> · freshness-warning: <any fact that decays quickly>

## Research Questions
| # | question | answered? |
|---|---|---|
| Q1 | <from mission.md> | yes / partial / no |

## Findings

### F1. <short finding title>
- Source: <URL or "user-provided"> · accessed <date>
- Summary: <≤3 sentences, facts only>
- Relevance: <which task/decision this feeds>
- Verdict: **USE** / **ADAPT** / **BUILD** — <one line why>

### F2. ...

## Conventions & Standards
<industry-standard approaches the mission should follow, each with source>

## Gaps & Unanswered
| question | why unanswered | impact on planning |
|---|---|---|

## Recommendation Summary
<≤5 bullets — the distilled takeaways planner must not miss>
```

## Field rules

- **Verdicts are mandatory.** A finding without USE/ADAPT/BUILD is a note, not a
  finding. Meaning:
  - **USE** — a premade solution fits as-is (library, template, tool, dataset).
    Planner will write a "wire it in" task, not a build task.
  - **ADAPT** — something close exists; extend or configure it. Planner writes an
    integration task + customization tasks.
  - **BUILD** — nothing adequate exists; build from scratch. Say what "from scratch"
    should reuse (patterns, conventions, adjacent libraries).
- **Sources on every claim.** URL + access date. For facts that decay (prices, versions,
  "current best practice"), add a freshness warning at the top — the executor may run
  days later.
- **Summaries ≤3 sentences.** research.md is a decision-feed, not a library. Link out
  for depth; never paste whole articles.
- **Gaps are deliverables.** A question scout couldn't answer within budget is recorded
  with its planning impact ("Q3 unanswered → planner must assume X for task sizing").
  Gaps are how planner knows what to treat as assumption instead of fact.
- **Recommendation Summary ≤5 bullets.** If it needs more, the mission probably
  discovered it's really two missions — say so there.

## Top-up mode (loop-back from executor/planner)

When sent back for ONE missing fact: append `### FT<n>. <fact>` under Findings with
source + verdict, mark the originating Research Question row answered, and note the
top-up in the header budget line (`+1 top-up`). Do not re-answer other questions.
