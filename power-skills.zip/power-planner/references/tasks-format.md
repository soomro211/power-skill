# tasks.md — Format & Authoring Guide

> planner owns this file's structure; executor owns Status/Notes updates at runtime.
> This board is what the executor mechanically follows and what wrap verifies against —
> precision here is what makes unattended execution possible.

## Template

```markdown
# Tasks — Mission <NNN>

plan-version: 1 · mission-ref: mission.md · updated: <YYYY-MM-DD>

| ID | Task | Status | Deps | Acceptance | Notes |
|----|------|--------|------|------------|-------|
| 1 | <what, verb-first> | todo | — | <verifiable-on-disk condition> | |
| 2 | <...> | todo | 1 | <...> | |
| 2-a | <...> | todo | 2 | <...> | batch: true |

## Next-Up
<ordered list of task IDs the executor should pick from first — deps satisfied>

## Change Log
| plan-version | change | reason |
|---|---|---|
| 1 | initial plan | grill+scout inputs |
```

## Field rules

- **ID** — hierarchical per contract.md (`1`, `1-a`, `2`…). Dispatch Task ID = this ID.
  Never reuse an ID after a re-plan; superseded tasks get `cancelled` with a pointer
  to the replacement ID in Notes.
- **Task** — verb-first, one outcome per row. It must read as an instruction a fresh
  subagent could act on ("Create Postgres schema for orders", not "Database stuff").
- **Status** — planner writes `todo`. Only executor changes it afterward
  (todo → in_progress → done / blocked; cancelled only with user approval).
- **Deps** — minimal set of IDs that must be `done` before this starts. Fewer is
  better; chains longer than 4 deep usually hide parallel structure or over-granularity.
- **Acceptance** — the contract the executor verifies against disk. Format:
  `exists: <path>` / `contains: <required content>` / `passes: <command or check>` /
  `<observable behavior>`. 1–3 criteria per task. Reference exact deliverable paths
  under `/home/z/my-project/download/` where applicable.
- **Notes** — `batch: true` marks micro-tasks the workflow may group into ONE subagent
  dispatch; `attempt n/3` is written by the executor; constraint reminders
  ("must stay offline").

## Task sizing rules

- One task = **one session-chunk**: something one focused subagent can finish and that
  can be verified independently. If acceptance needs three features to exist at once,
  split the task.
- Each task produces a **single clear output** (file, endpoint, section, dataset).
- 5–15 tasks is the healthy range for most missions. More than 20 usually means
  sub-subtasks should collapse; fewer than 3 usually means the mission is trivial and
  should have skipped the pipeline (ceremony budget).
- Every mission.md Done-Definition item maps to ≥1 task — planner checks this mapping
  explicitly before exiting (traceability is what wrap verifies).

## Acceptance criteria: good vs bad

| Bad | Good |
|---|---|
| "Auth works" | "passes: login with valid creds lands on dashboard; wrong password shows error — checked in app" |
| "Nice chart" | "exists: download/sales-chart.png; contains: monthly series Jan–Jun, axis labels, source note" |
| "Handle big files" | "passes: 100k-row CSV imports in one run without error — import log shows row count" |

## Re-plan rules (version bump)

When a re-plan is triggered (scope change or executor 3-strike loop-back):

1. NEVER modify history: all `done`/`in_progress` rows keep their IDs and statuses.
2. `cancelled` superseded rows; add new rows with FRESH IDs (continue numbering).
3. Bump `plan-version`, add a Change Log row: what changed and the trigger
   (loop-back evidence or scope-change decision reference).
4. Rebuild §Next-Up from the new board state.
5. Re-check the Done-Definition ↔ task mapping after changes.
6. Log the re-plan in mission.md Decisions Log (`re-plan → plan-version N`).
