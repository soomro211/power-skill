# POWER SUITE — Portable Skill Package (v1.0)

A 7-skill pipeline suite that turns a vague idea into a researched, planned,
executed, and archived work session — with a crash-safe workspace that any AI
agent can resume without prior context.

## What's inside

| Folder | Skill | Role |
|--------|-------|------|
| `power/` | power | Entry + orchestrator. Explicit invocation only: `power <task>`, `power continue`, `power status`, bare `power` |
| `power-grill/` | power-grill | Stage 1 — always runs. Adaptive questioning (vague → 16–20 Qs; clear → 3–6) until mission is unambiguous |
| `power-scout/` | power-scout | Stage 2 — research premade solutions, standards, prior art (budget: ≤6 searches, ≤6 reads) |
| `power-planner/` | power-planner | Stage 3 — decompose the mission into a dependency-ordered task board |
| `power-workflow/` | power-workflow | Stage 4 — build the execution structure (playbooks: software-build, research-report) |
| `power-executor/` | power-executor | Stage 5 — sequential supervisor loop; one subagent per task; verify-don't-trust |
| `power-resume/` | power-resume | Off-pipeline — pure reading guide for any agent (or new session) recovering state |

## Install

Copy the 7 folders (not this README) into the skills directory your agent reads.
Keep the folder names exactly as-is — cross-references use them.

- **Claude Code / Claude Desktop**: `~/.claude/skills/`
- **Generic agent hosts**: the host's `skills/` directory (e.g. `<project>/skills/`)
- **Manual / other agents**: place the folders anywhere readable and instruct the
  agent to treat each `SKILL.md` as a skill definition with its `references/`
  loaded on demand.

Verification: after installing, 19 files across 7 folders should exist
(each `SKILL.md` plus 12 reference files total).

## Use

1. Start a session: tell your agent `power <what you want done>`.
2. The agent runs grill → scout → planner → workflow → executor → wrap.
3. Every stage ends with a one-line "say stop to change course" — you can
   interrupt at any time. The only hard gate: wrap asks for your approval
   before archiving.
4. If the session, context, or agent changes: have the new agent invoke
   `power-resume` (or just `power continue`). It reads
   `worklog.md` → `.power/README.md` → `.power/active/state.md` → mission →
   tasks → recent worklog → workflow/context, then re-enters via `power`.

## Workspace it creates (in your project directory)

```
worklog.md                  permanent append-only journal (beacon header)
.power/
  README.md                 bootstrap for foreign agents (no skills needed to understand it)
  active/
    state.md                current stage, owner-agent, heartbeat — the standing brief
    mission.md              locked mission + decisions log
    context/research.md     scout findings (USE/ADAPT/BUILD verdicts)
    tasks.md                task board (todo/in_progress/done/blocked/cancelled)
    workflow.md             execution structure for the current playbook
  sessions/NNN-slug/        archived sessions after wrap approval
```

No build step, no dependencies — plain Markdown skills. `contract-version: 1`.
