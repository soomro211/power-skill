---
name: power-workflow
description: Stage 4 of the power pipeline — execution design. Do not invoke standalone; power runs it automatically. Reads tasks.md, picks and adapts an execution playbook (software-build or research-report) into workflow.md — phases, task mapping, per-phase verification, checkpoint schedule, and subagent dispatch notes — or builds a custom playbook when none fits.
---

# power-workflow — design HOW the tasks get executed

> Pipeline-only: runs as stage 4 of `power`. If invoked standalone, refuse and point
> to `power`.

planner decided WHAT; you decide HOW the executor runs it: which playbook shape fits,
what gets verified at each phase, when checkpoints happen, and what each dispatch
needs to know. A good workflow.md lets the executor run for hours without improvising.

## Inputs

- `.power/active/tasks.md` — the board (IDs, deps, acceptance, batch flags).
- `.power/active/mission.md` — constraints, process prefs (G1–G8), risks.
- `.power/active/context/research.md` — verdicts that shape the execution approach.

## Step 1 — Pick the playbook

| Cue | Playbook |
|---|---|
| Deliverable is running code; verbs: build/implement/configure/integrate | `references/playbooks/software-build.md` |
| Deliverable is a synthesized document; verbs: gather/analyze/draft/write | `references/playbooks/research-report.md` |

Confidence rule: if the fit is < ~70% (mixed missions — e.g., "research then build a
tool from findings"), don't force it — compose a CUSTOM playbook in the same structure
(§Custom playbooks), possibly chaining the two libraries' phases. Record why the
standard playbook didn't fit in workflow.md's header (`fit:` line).

## Step 2 — Adapt the playbook to THIS board

The playbook is the skeleton; the board is the flesh:

1. **Map every task ID to a phase** (the Phases table's `tasks` column). Every ID
   appears exactly once (batched groups may share a row). An unmappable task is a
   planning smell — flag it back to power rather than wedging it in.
2. **Concretize verification**: replace the playbook's generic verification focus with
   the task's actual acceptance criteria at each phase; note what evidence the
   executor should capture (command output, rendered file, screenshot path).
3. **Set the checkpoint schedule**: per-task checkpoints are contract-level and
   non-negotiable; add phase-boundary checkpoints from the playbook. If the user asked
   for sparser progress signals (mission G2), that changes NOTICES, not journaling.
4. **Mark dispatch specifics** per task/phase: batch groups (`batch: true`), host
   skills to load in the dispatch prompt (fullstack-dev / docx / pdf / xlsx / pptx /
   web-search), constraint reminders worth repeating (stack locks, offline, do-not-touch).
5. **Risks**: pull mission risks (F1–F8) + playbook pitfalls into a short list with
   what the executor should do when each materializes (which fail-type it maps to).

## Step 3 — Write workflow.md

Per the skeleton from `skills/power/references/init.md` Template F, filled with:

- Header: playbook name, fit rationale, source plan-version.
- Phases table (phase / tasks / verify / checkpoint).
- Dispatch Notes (batching, skills, constraint reminders).
- Risks (with fail-type mapping: retryable / content-gap / spec-gap / plan-gap —
  see executor's verify-protocol).

Keep it lean: workflow.md is an execution recipe, not an essay. If it exceeds ~120
lines it's re-explaining the playbooks — cut.

## Step 4 — Exit

Report ≤3 lines: playbook chosen (+fit %), phase count, batching summary.
Hand back to power: state.md `stage: executor`, journal the exit.

## Custom playbooks (when neither library fits)

Same structure, honest phases. Rules of thumb:

- 3–6 phases; each phase = a kind of work with its own verification focus.
- Order phases so each one's output is the next one's verifiable input.
- Verification focus comes from acceptance criteria, never from vibes ("review it"
  is not verification; "all 5 sections present, each ≤800 words, sources cited" is).
- Say in the `fit:` line what you drew from which library playbook — future missions
  of this type should graduate into a reusable library entry (note it to power; new
  playbook files are a wrap/retro decision, not an executor-time one).
