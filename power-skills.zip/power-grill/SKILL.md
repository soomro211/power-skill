---
name: power-grill
description: Stage 1 of the power pipeline — requirements interrogation. Do not invoke standalone; power runs it automatically at session start. Produces mission.md by questioning the user adaptively — a full 16–20 question interrogation in rounds of 4–6 for vague requests, or a 3–6 question confirmation pass for clear ones — every question offering concrete options with a recommended default, answers journaled to disk each round.
---

# power-grill — interrogate, then write the mission

> Pipeline-only: this skill runs as stage 1 of `power`. If invoked standalone, refuse
> and tell the user to invoke `power` instead. In re-grill mode (sent back by the
> executor) follow §Re-grill at the end.

You turn a fuzzy human request into `mission.md` — the document every later stage
trusts instead of re-asking. Two things make grill valuable rather than annoying:
**adaptive depth** (match the interrogation to how vague the request actually is) and
**journaling every answer to disk immediately** (so a context loss never eats the
user's answers).

## Inputs

- The user's request (verbatim — quote it in Background).
- Any existing workspace files (a resume, an old mission, a repo).
- Re-grill: a specific question or ambiguity handed back by the executor.

## Step 1 — Score coverage

Read `references/coverage.md`. Score the 12 dimensions against the user's initial
request (their words only, not your assumptions) → FULL / MEDIUM / CONFIRM mode and
the question budget. State the mode in one line: "vague request → full grill (target
16–20 questions)".

## Step 2 — Interrogate in rounds

Per round (4–6 questions, host AskUserQuestion tool):

1. Pick questions from `references/question-bank.md` — uncovered dimensions first,
   blocking dimensions (goal, scope, constraints) before nice-to-know ones; category H
   replaces generics when the domain is obvious.
2. Every question: 3–4 CONCRETE options (names, numbers, examples — never "simple/
   professional" vagueness) and exactly one recommended default. The recommendation
   is what you would pick given everything said so far — say why in the question text
   when the reason isn't obvious.
3. multiSelect only where choices genuinely co-exist (deliverable formats, features).
4. **Journal immediately after each round** (this is the crash-safe rule from
   `skills/power/references/contract.md`): append answers into the mission.md draft
   sections they belong to, and one Decisions Log row per consequential choice.
   Do not batch journaling to the end.
5. Re-score coverage → next round or stop (stopping rules in coverage.md).

Tone: brisk and structured, not an interrogation montage. Groups of related questions,
clear options, zero filler.

## Step 3 — Write mission.md

Finalize `.power/active/mission.md` exactly per `references/mission-format.md`:

- Done-Definition: 3–7 bullets, each verifiable on disk (reject vague ones).
- Scope-Out explicitly records what the user excluded or never requested.
- Every unanswered dimension lands in Open Questions with a proposed assumption
  (coverage.md §Assumption protocol) — auto autonomy means the pipeline proceeds on
  assumptions, but they are recorded and announced.
- Stamp the header (session, contract-version: 1, autonomy, language).

## Step 4 — Exit

1. Announce the assumptions line ("assuming X — flag if wrong").
2. Report in ≤3 lines: mission one-liner + Done-Definition count + open questions count.
3. Hand back to power: state.md `stage: scout`, journal the exit. Power prints the
   stage-end notice.

## Re-grill (loop-back from executor)

The executor only sends back SPECIFIC ambiguities ("task 4-b assumes invoice numbering
format — no decision exists"). Then:

- Ask ONLY the missing question(s) — one round, options + recommendation as usual.
- Append answers: mission.md relevant section + Decisions Log row
  (`loop-back grill←executor` reason) + resolve the originating Open Question row.
- Never rewrite Goal/Scope in re-grill — scope changes belong to planner re-plans.

## Question quality bar (the difference between grill and a form)

- Bad option set: `Simple / Professional / Advanced` (adjectives — means nothing).
- Good option set: `single HTML page` / `Next.js app with auth` / `static generator,
  deploy anywhere` (the user can SEE choosing each).
- Bad question: "Any constraints?" Good question: "Must this run without internet
  access, or are cloud APIs fine?"
- If your options make the user type a novel, your options are wrong; if they can only
  answer "other", your options missed the space.
