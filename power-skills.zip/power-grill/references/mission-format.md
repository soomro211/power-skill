# mission.md — Format & Authoring Guide

> grill owns this file. It is the constitution of the mission: every later stage
> (scout, planner, workflow, executor, wrap) reads it instead of re-asking the user.
> Write it in the conversation language. Stamp `contract-version: 1`.

## Template

```markdown
# Mission <NNN> — <slug>

session: <NNN> · contract-version: 1 · autonomy: auto+interruptible
language: <conversation language> · created: <YYYY-MM-DD>

## Goal
<1–2 sentences. What exists when the mission succeeds. No "how".>

## Background
<3–5 sentences: where this came from, what problem it solves, what preceded it.>

## Scope-In
- <concrete capability/deliverable>
- <...>

## Scope-Out
- <explicitly excluded, so later stages don't gold-plate>
- <...>

## Constraints
- <time / tech / budget / compatibility / non-functional limits>

## Done-Definition
- <observable, verifiable-on-disk condition>
- <...>

## Success Criteria
- <the measure that says the mission was worth doing>

## Stakeholders
- <who uses/reviews the result, and what they care about>

## Decisions Log
| timestamp | decision | reason | source |
|---|---|---|---|
| <ts> | <what was decided> | <why> | grill |

## Open Questions
| question | proposed assumption | status |
|---|---|---|
| <unresolved> | <what we'll assume if unanswered> | open |
```

## Slot-by-slot guidance

- **Goal** — the single paragraph every later agent re-reads. If it contains "and"
  three times, the mission probably needs splitting.
- **Scope-Out** — as important as Scope-In. Unstated exclusions become scope creep in
  the executor loop.
- **Constraints** — record the *reason* with each constraint when the user gave one
  ("must run offline — kiosk deployment"); reasons survive contact with re-planning.
- **Done-Definition** — the wrap checklist checks these items one by one, so each must
  be checkable without judgment calls. Aim for 3–7 items.
- **Decisions Log** — append-only. Loop-backs, scope changes, and notable Q&A choices
  all land here. Never delete rows.
- **Open Questions** — every question grill asked but the user never answered lands
  here with a proposed assumption, so the pipeline can keep moving (auto autonomy)
  without silently guessing.

## Done-Definition: good vs bad

| Bad (unverifiable) | Good (verifiable on disk) |
|---|---|
| "The auth is good" | "Login rejects wrong passwords with a visible error and creates a session on success — verified by running the app and the auth test suite" |
| "Nice report" | "A 10–15 page PDF in /home/z/my-project/download/ with market size, 3 competitor profiles, and sourced figures" |
| "Handles scale" | "Dashboard loads in <2s with 100k rows — verified by the load script output saved to the log" |

## Revision rules

- grill may rewrite mission.md freely until the stage exits (state.md `stage: planner`).
- After that, changes are append-only: new decisions go to the Decisions Log, new
  knowledge to Open Questions. Rewriting Goal/Scope after grill requires a planner
  re-plan (new plan-version) so tasks.md and mission.md never disagree.
