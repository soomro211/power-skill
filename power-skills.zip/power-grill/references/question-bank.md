# Grill Question Bank — ~70 Questions, 8 Categories

> grill's ammunition. Pick per round by coverage gap (see coverage.md), highest impact
> first. Adapt wording to the domain; the scaffolds show the shape, not literal text.
> Every question offered to the user gets 3–4 CONCRETE options (examples, names,
> numbers — never vague adjectives) and exactly one recommended default.

## Contents
[A. Goal & Success](#a-goal--success) · [B. Audience & Usage](#b-audience--usage) ·
[C. Scope](#c-scope) · [D. Constraints](#d-constraints) ·
[E. Assets & Facts](#e-assets--facts) · [F. Risks & Edge Cases](#f-risks--edge-cases) ·
[G. Process Preferences](#g-process-preferences) · [H. Domain Deep-Dives](#h-domain-deep-dives)

## A. Goal & Success

**A1. What exists when this mission is done — the artifact, concretely?**
Options: `working app/site` / `document (PDF/docx/xlsx)` / `dataset or analysis output` / `a reusable template or tool` — Rec: mirror whatever noun the user emphasized
Listen for: "make it better/improve" → force a concrete artifact noun.

**A2. Why now — what triggered this?**
Options: `deadline/event` / `recurring pain` / `opportunity spotted` / `boss/client asked` — Rec: whatever explains urgency; it calibrates depth vs speed
Listen for: deadline dates — they belong in Constraints.

**A3. How will you judge success a week later?**
Options: `it works without me fixing things` / `someone specific approves it` / `a metric moves` / `I can reuse it` — Rec: first option for personal tools, second for client work
Listen for: a measurable target → capture verbatim in Success Criteria.

**A4. What's the ONE thing this must not get wrong?**
Options: free text prompted with examples (`data correctness` / `visual polish` / `speed` / `not breaking what exists`) — Rec: none; this question has no default
Listen for: this usually becomes the top Done-Definition item.

**A5. Is there a version of this that's a MUST vs nice-to-have?**
Options: `MVP first, extend later` / `one complete pass` / `iterate with me live` — Rec: MVP first — smaller done-definitions verify faster
Listen for: the MVP cut-line → Scope-In vs Scope-Out.

**A6. What does "done" NOT include?**
Options prompted with the artifact's usual extras (`deployments` / `docs` / `tests` / `branding`) — Rec: exclude the extras the user doesn't mention
Listen for: these fill Scope-Out.

**A7. If this succeeds quietly, what changes for you?**
Options: `saves recurring time` / `enables a next project` / `impresses someone specific` / `pure curiosity` — Rec: n/a
Listen for: reveals the real audience (cross-check B1).

**A8. Have you (or anyone) attempted this before? What happened?**
Options: `yes — failed at X` / `yes — worked but outgrown` / `no, first attempt` — Rec: n/a
Listen for: prior failures are constraint goldmines.

## B. Audience & Usage

**B1. Who actually uses/reads the result?**
Options: `just me` / `my team` / `a client/boss` / `public` — Rec: mirror the request's phrasing
Listen for: "client/boss" → polish and review gates matter more.

**B2. Where will it be used/run?**
Options: `this machine only` / `shared drive/repo` / `a server/hosted` / `offline/kiosk` — Rec: this machine unless said otherwise
Listen for: hosting/deployment is a classic Scope-Out candidate.

**B3. How often will it be used — once or repeatedly?**
Options: `one-shot` / `weekly-ish` / `daily` — Rec: n/a
Listen for: repeated use → maintainability and docs rise in priority.

**B4. Who reviews/approves it before it counts as done?**
Options: `only you (user)` / `me + one reviewer` / `a committee/process` — Rec: only the user — matches auto autonomy
Listen for: external approvers → their criteria belong in Done-Definition.

**B5. What devices/contexts must it work in?**
Options: `desktop only` / `desktop + mobile` / `any browser` / `print` — Rec: desktop only unless stated
Listen for: mobile/print constraints are silent fail-modes.

**B6. What skill level does the audience have with this kind of thing?**
Options: `expert (same domain as me)` / `professional layperson` / `general public` — Rec: mirror how the user describes others
Listen for: drives jargon level and onboarding surfaces.

**B7. Language(s) for the deliverable?**
Options: `conversation language` / `English` / `bilingual` / `other: __` — Rec: conversation language
Listen for: non-default answers go to Constraints.

**B8. Does anyone else need to CONTINUE this work later?**
Options: `no, just me` / `yes — teammates` / `yes — other AI agents/sessions` — Rec: yes-other-agents if the user runs power (that's its point)
Listen for: "yes" → emphasize journaling discipline in the plan.

## C. Scope

**C1. Which capabilities are core? List the top 3.**
Options: free-text prompt with the artifact's typical feature set — Rec: n/a
Listen for: these seed planner's tasks 1..3.

**C2. What's tempting but explicitly OUT this round?**
Options prompted from C1's neighborhood (`auth if app` / `charts if report` / `automations`) — Rec: propose one exclusion yourself
Listen for: a confident "that too" = scope creep caught early.

**C3. Existing thing being replaced/fixed — what's wrong with it?**
Options: `nothing exists yet` / `exists but broken at X` / `exists but manual` — Rec: n/a
Listen for: "broken at X" → X is a mandatory Done-Definition item.

**C4. Must this integrate with anything existing?**
Options: `nothing` / `<named systems>` / `yes but later` — Rec: nothing unless named
Listen for: named systems → integration tasks + version constraints.

**C5. Data: where does input data come from and who owns it?**
Options: `user-provided files` / `public/web` / `generated/fake for now` / `API (which?)` — Rec: user-provided if they mentioned files
Listen for: file formats and volumes belong in Assets (E).

**C6. Rough size — how big is the smallest acceptable result?**
Options: `hours-scale` / `days-scale` / `weeks-scale` — Rec: n/a
Listen for: anchors planner's task sizing.

**C7. Which parts could be cut on a bad day and the mission still counts?**
Options: free text from C1 list — Rec: propose the least-mentioned item
Listen for: this is the fallback cut-line if execution hits trouble.

**C8. Is there a hard external definition of correct (spec/standard/regulation)?**
Options: `no` / `yes: <name it>` — Rec: n/a
Listen for: named standards go verbatim into Constraints.

## D. Constraints

**D1. Hard deadline?**
Options: `none` / `date: __` / `"asap but right"` — Rec: none
Listen for: dates → Constraints + task sizing sanity check.

**D2. Tech stack: any locked choices?**
Options: `you pick sensibly` / `locked: <stack>` / `match my existing: <repo>` — Rec: you pick, favor boring proven choices
Listen for: "locked" kills planner freedom — record verbatim.

**D3. Anything this must NOT touch?**
Options: `nothing` / `<files/systems/branches>` — Rec: nothing
Listen for: write these into Constraints literally ("do not modify X").

**D4. Budget limits (API calls, services, licenses)?**
Options: `none` / `keep it free/local` / `small budget OK: ~__` — Rec: keep it free/local
Listen for: "free" forbids paid-API-based designs at scout/planner time.

**D5. Performance requirements that actually matter?**
Options: `standard is fine` / `must handle <scale>` / `latency-critical: <target>` — Rec: standard
Listen for: "100k rows", "sub-second" → testable criteria.

**D6. Security/privacy constraints?**
Options: `nothing sensitive` / `personal data involved` / `must stay local` — Rec: nothing sensitive
Listen for: "stay local" forbids cloud services in every task.

**D7. Compatibility requirements (OS, versions, existing formats)?**
Options: `this environment only` / `must match: <target>` — Rec: this environment
Listen for: exact versions → record them, they become acceptance criteria.

**D8. What's the worst acceptable outcome — what must never happen?**
Options: `data loss` / `public embarrassment` / `wasted money` / `broken existing workflow` — Rec: n/a
Listen for: the answer becomes a verification target at wrap.

## E. Assets & Facts

**E1. What existing files/materials feed this?**
Options: `none` / `<paths named>` — Rec: n/a
Listen for: verify paths exist NOW; missing assets block planning.

**E2. Access/credentials available? (API keys, accounts, servers)**
Options: `all available` / `limited: __` / `none — must work without` — Rec: n/a
Listen for: "none" reshapes the whole approach (offline-first).

**E3. Brand/style assets to follow (colors, fonts, templates)?**
Options: `no brand, your call` / `follow: <reference>` — Rec: your call, clean and neutral
Listen for: named references → scout looks them up; planner pins them.

**E4. Prior art you already know of?**
Options: `none` / `<named tools/repos/articles>` — Rec: n/a
Listen for: feeds scout's starting list — never re-research what the user knows.

**E5. Anything about your workflow I should match?**
Options: `no preference` / `<conventions named>` — Rec: no preference
Listen for: conventions ("I always want tests") become standing constraints.

**E6. Who do I ask when a fact is missing mid-execution?**
Options: `ask me anytime` / `prefer assumptions, batch questions` — Rec: assumptions + batch, per auto autonomy
Listen for: "ask me anytime" softens the interruptible default for this mission.

**E7. Are there facts only you can confirm (numbers, names, dates)?**
Options: `I'll list them` / `figure them out from sources` — Rec: n/a
Listen for: unconfirmed facts become Open Questions with assumptions.

**E8. What exists AROUND this project (docs, wikis, related missions)?**
Options: `nothing` / `<named>` — Rec: n/a
Listen for: cross-references for README and future sessions.

## F. Risks & Edge Cases

**F1. What's the most likely way this goes wrong?**
Options: prompted from context (`scope explodes` / `external dependency breaks` / `quality too low`) — Rec: n/a
Listen for: mitigations go into workflow.md Risks.

**F2. Which edge cases genuinely matter?**
Options: `empty/zero inputs` / `huge inputs` / `malformed inputs` / `<domain-specific>` — Rec: the ones matching the data source
Listen for: matters-worthy ones become acceptance criteria.

**F3. What happens the first time it fails in front of someone?**
Options: `needs a fallback: <what>` / `acceptable risk` — Rec: acceptable for internal tools
Listen for: "needs fallback" → a task for it.

**F4. Anything time-sensitive inside the data (freshness windows)?**
Options: `no` / `yes: <window>` — Rec: no
Listen for: "quotes valid today" style facts → scout must date-stamp findings.

**F5. Dependencies outside your control?**
Options: `none` / `<named services/people>` — Rec: none
Listen for: named dependencies get contingency notes in workflow.md.

**F6. Is anything here legally/ethically sensitive (licensing, copyright, personal data)?**
Options: `no` / `yes: <which>` — Rec: no
Listen for: "yes" → scout researches the constraint; planner adds a compliance task.

**F7. What would make you throw this away and restart?**
Options: free text — Rec: n/a
Listen for: the abort condition — record it so the executor stops instead of polishing a doomed path.

**F8. Which of these risks are you WILLING to carry without mitigation?**
Options: `<from F1-F6>` — Rec: n/a
Listen for: explicit risk acceptance prevents over-engineering.

## G. Process Preferences

**G1. Autonomy level for THIS mission?**
Options: `auto + interruptible (default)` / `pause after each stage` / `pause for every task` — Rec: auto + interruptible
Listen for: deviation is stamped into mission.md autonomy field.

**G2. How often do you want a progress signal?**
Options: `every task (default)` / `every stage` / `only when blocked` — Rec: every task
Listen for: "only when blocked" mutes executor's per-task notices.

**G3. Deliverable format(s) required?**
Options: `<app/code>` / `PDF` / `docx` / `xlsx` / `slides` / `web page` — Rec: mirror the request
Listen for: formats map to host skills in dispatch notes.

**G4. Where do deliverables go?**
Options: `standard download folder (default)` / `specific path: __` — Rec: standard
Listen for: overrides the deliverable rule for this mission (record it!).

**G5. Testing expectations?**
Options: `works when I try it` / `automated tests where sensible` / `full test coverage` — Rec: works when tried
Listen for: "automated tests" → test tasks appear in tasks.md.

**G6. Documentation expectations?**
Options: `minimal (README)` / `usage docs` / `extensive` — Rec: minimal
Listen for: "extensive" → doc tasks with word-structure criteria.

**G7. Stop-and-ask triggers you want regardless of autonomy?**
Options: `spending beyond: __` / `deleting/overwriting existing files` / `none` — Rec: overwriting existing files
Listen for: hard user gates are absolute — they outrank auto autonomy.

**G8. After wrap: archive immediately or keep active a while?**
Options: `archive on approval (default)` / `keep active for follow-ups` — Rec: archive on approval
Listen for: "keep active" changes the wrap procedure's last step.

## H. Domain Deep-Dives (pick per detected domain)

**H1. (web app) Pages/screens and their primary actions?**
Options: prompted skeleton (`landing / dashboard / settings`) — Rec: smallest coherent set
Listen for: screen list seeds tasks; resist extras.

**H2. (web app) Auth needed at all?**
Options: `no — local/single user` / `simple password gate` / `full accounts` — Rec: no
Listen for: "full accounts" doubles the mission — confirm.

**H3. (data) What does the raw data actually look like?**
Options: `<user shows sample>` / `described schema` — Rec: ask for a sample when possible
Listen for: schema mismatch is the #1 data-task failure — verify early.

**H4. (data) Exact output shape the consumer expects?**
Options: `columns: __` / `chart types: __` / `their template` — Rec: n/a
Listen for: output shape becomes literal acceptance criteria.

**H5. (docs) Structure/section requirements up front?**
Options: `standard structure` / `their template` / `you propose` — Rec: you propose, confirm before planner
Listen for: fixed templates get pinned in Constraints.

**H6. (docs) Tone/voice references?**
Options: `match sample: __` / `neutral professional` — Rec: neutral professional
Listen for: tone is subjective — pair it with concrete style rules.

**H7. (research) What decisions will the research feed?**
Options: free text — Rec: n/a
Listen for: decisions define what counts as an answer (scout's verdict bar).

**H8. (research) Source quality bar?**
Options: `primary sources only` / `reputable secondary OK` / `anything credible` — Rec: reputable secondary
Listen for: "primary only" shrinks scout's budget per finding.
