# Coverage Checklist — Depth Scoring & Stopping Rules

> Decides how hard grill interrogates (adaptive depth, decision D2) and when to stop.

## The 12 coverage dimensions

| # | Dimension | Typically answered by |
|---|---|---|
| 1 | Goal (artifact noun, concrete) | A1, A4 |
| 2 | Outcome measure (what success looks like) | A3 |
| 3 | Audience & context of use | B1–B5 |
| 4 | Scope-in (core capabilities) | C1, A5 |
| 5 | Scope-out (explicit exclusions) | A6, C2 |
| 6 | Constraints (time/tech/budget/compat) | D1–D7 |
| 7 | Assets & facts on hand | E1–E4 |
| 8 | Data source & shape | C5, H3/H4 |
| 9 | Risks & must-never-happen | A4, D8, F1, F8 |
| 10 | Process prefs (autonomy, checkpoints, stop-triggers) | G1, G2, G7 |
| 11 | Deliverable format & destination | G3, G4 |
| 12 | Done-Definition (verifiable items) | synthesized from 1, 3, 5, 9 |

A dimension counts as **covered** only if the user's own words establish it — your
assumptions don't count. Mark each dimension covered / partial / missing while
listening; coverage is scored on the INITIAL request before round 1, then re-scored
after every round.

## Depth bands (score = dimensions covered by the initial ask)

| Score | Mode | Question budget |
|---|---|---|
| 0–5 | FULL | 16–20 questions, rounds of 4–6 |
| 6–8 | MEDIUM | 8–12 questions, rounds of 4 |
| 9+ | CONFIRM | 3–6 questions — verify what you think you heard, confirm assumptions |

Worked example: *"Build me a dashboard for my Shopify sales data"* — covers goal (1,
dashboard), audience (1, me), data source (8, Shopify) → score 3 → FULL mode.

## Stopping rules — stop asking when ANY holds

1. **Coverage green**: all 12 dimensions covered or explicitly waived.
2. **Fatigue signals**: one-word answers, "whatever you think", "just go", repeated
   "same as before". Then: fill remaining gaps from the assumption protocol and move on.
3. **User says go**: the user's explicit stop outranks the checklist.
4. **Budget exhausted**: total questions reached the band's ceiling. Never exceed 20
   questions in one mission without the user asking to continue.

Remaining missing dimensions → assumption protocol (below), never silent gaps.

## Assumption protocol

For each still-missing dimension:

1. Choose a sensible default (question-bank recommendations are the defaults).
2. Record it in mission.md Open Questions: `| question | proposed assumption | open |`
3. Mention the assumption to the user in one line at grill exit ("assuming desktop-only
   use — flag if wrong"). Auto autonomy means the pipeline proceeds on the assumption;
   the record keeps it honest and reversible.

## Round composition

Per round pick 4–6 questions: first from dimensions marked missing that BLOCK other
decisions (goal, scope, constraints), then highest-impact remaining. Category H
questions replace generic ones whenever the domain is known. Ask via the host
AskUserQuestion tool: each question gets 3–4 concrete options, exactly one recommended,
multiSelect where choices genuinely co-exist (e.g., deliverable formats).

## After each round

Re-score coverage → journal the round's Q&A into mission.md draft sections + Decisions
Log immediately (crash-safe: a context loss mid-grill resumes from mission.md, see
contract.md §Journaling) → next round or exit.
