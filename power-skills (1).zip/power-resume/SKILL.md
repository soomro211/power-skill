---
name: power-resume
description: Standalone reading guide for cold-start agents — use when a session's context was lost, a new agent takes over mid-mission, the user asks to resume/take over/continue previous power work or asks what the current mission state is, or you find a .power/active/ folder and root worklog beacon in the workspace. Points to the exact files to read and in what order so any agent can understand the power pipeline. Contains nothing else — it writes nothing, verifies nothing, and runs nothing.
---

# power-resume — a map, nothing more

You are here because your context is fresh: the session changed, the context was
cleared, or another agent started this work. Everything you need is already on disk.
This guide only tells you WHERE to look and IN WHAT ORDER. Read the files yourself;
they are self-describing. Do not take the guide's word for mission state — the files
are the truth.

## Read in this order

1. **`worklog.md`** (workspace root) — the beacon at the top says whether a power
   session is active and where it lives. Read the last ~10 entries to see what just
   happened.
2. **`.power/README.md`** — the workspace map and the binding rules (short).
3. **`.power/active/state.md`** — the standing brief: current stage, `now` (what was
   in the air), `next`, blockers, who claimed the session and when.
4. **`.power/active/mission.md`** — the goal, scope, constraints, **Done-Definition**
   (what "finished" means), the Decisions Log (why things are the way they are), and
   Open Questions with proposed assumptions.
5. **`.power/active/tasks.md`** — the board: what is done, in progress, pending,
   blocked. The `Acceptance` column is how each task will be judged.
6. Tail of **`worklog.md`** again if you skipped step 1 — the work log is the ground
   truth of what was actually done, entry by entry.
7. **Only if you are about to continue EXECUTION**: `.power/active/workflow.md` (the
   execution recipe) and `.power/active/context/research.md` (findings & verdicts).

That's it — in normal cases steps 1–5 suffice; the rest on demand.

## What the pipeline is (so the files make sense)

A power session runs a mission through: **grill** (asks the user, writes mission.md)
→ **scout** (researches, writes context/research.md) → **planner** (decomposes, writes
tasks.md) → **workflow** (designs execution, writes workflow.md) → **executor**
(dispatches one subagent per task, verifies acceptance criteria on disk, journals to
worklog.md) → **wrap** (verifies the Done-Definition, reports, archives on approval).
The stage pointer lives in `state.md`.

## The four rules (binding on every agent here)

1. `worklog.md` is **append-only** — add entries, never edit history.
2. **One writer per file** — each file's writer is fixed; everyone else reads.
3. `.power/sessions/` is **read-only** archive.
4. **Verify before continuing** — trust artifacts on disk, not status text. If
   `state.md` shows a task in flight, check its acceptance criteria against the disk
   yourself before acting.

## Now what

You understand the mission. To ADVANCE the pipeline, invoke **`power`** — it is the
only state-machine driver (it will resume from `state.md`, claim ownership, and
continue at the recorded stage). Use your own reading of the files for read-only
judgment: answering the user's questions, assessing progress, or preparing your
takeover. If the power skills are not installed in your environment, work directly
from the files — they contain everything needed to continue honestly.
