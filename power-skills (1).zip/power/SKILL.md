---
name: power
description: Personal mission OS that runs multi-step work as a managed, resumable pipeline. Use EXPLICITLY whenever the user says "power ...", "power init", "power continue", "power status", asks to start/run/resume a power session, or wants a project managed with mission files, task boards, and resumable state that other agents can pick up. Orchestrates the pipeline grill (clarify) → scout (research) → planner (tasks) → workflow (execution recipe) → executor (subagent task loop) → wrap (verify + archive), and handles interrupts, scope changes, and session archives. Skip it for trivial one-step requests that fit in a single tool chain.
---

# power — orchestrator of the mission pipeline

You are the state machine. You do not do the stage work yourself — you drive it:
invoke each stage skill, watch for its exit condition, checkpoint, continue. The
filesystem is your memory; `.power/active/state.md` is your stage pointer. All
workspace rules come from `references/contract.md` — read it first if anything about
files, statuses, or formatting is in question.

## When to run / not run

Run when the user explicitly invokes power (`power <task>`, `power continue`,
`power status`, bare `power`) or clearly asks for a power-managed session.

Do NOT run the pipeline for trivial requests — anything with a clear intent that fits
in one tool chain (a quick question, a one-file edit, a single lookup). Handle those
directly and say why no mission was opened. When a request is borderline (multi-file,
or produces work a future session must find), offer the pipeline in one line and let
the user decide.

## Invocation parsing

| User says | You do |
|---|---|
| `power <task description>` | §Session check → new or resume → run pipeline toward the task |
| `power continue` / `power resume` | Resume active session (or say none exists and offer to start) |
| `power status` / bare `power` | Status report (below) |
| `power stop` (mid-stage) | Interrupt protocol |
| `power archive` / `power wrap` | Jump to wrap if executor stage is complete; otherwise report what's unfinished |

## Session check

1. Does `.power/active/state.md` exist?
   - **No** → new session: run `references/init.md` scaffolding, then stage 1 (grill).
   - **Yes** → resume: follow `references/state-machine.md` §Resume procedure
     (verify in-flight work on disk before trusting it, claim ownership, continue at
     the recorded stage).
2. If the task text arrived together with an active session, classify first
   (§New task vs scope change).

## The pipeline

```
grill → scout → planner → workflow → executor → wrap
  mission  research   tasks     workflow   work+log   report+archive
```

| Stage | Skill (read its SKILL.md and follow it) | Produces |
|---|---|---|
| 1 clarify | `skills/power-grill/SKILL.md` | `.power/active/mission.md` |
| 2 research | `skills/power-scout/SKILL.md` | `.power/active/context/research.md` |
| 3 decompose | `skills/power-planner/SKILL.md` | `.power/active/tasks.md` |
| 4 design execution | `skills/power-workflow/SKILL.md` | `.power/active/workflow.md` |
| 5 execute | `skills/power-executor/SKILL.md` | deliverables in the deliverables directory + journals |
| 6 wrap | you, per `references/state-machine.md` §Wrap | mission report → archive |

Stage skills refuse standalone use. You are their only valid caller.

## Stage dispatch procedure

For each stage, in order:

1. Read the stage skill's SKILL.md (and the references it points to for the work at
   hand). Follow it — do not improvise the stage's procedure.
2. When the stage reports completion (its exit condition holds), run the transition
   procedure in `references/state-machine.md`: update `state.md`, journal, print the
   notice, continue.
3. If a stage cannot proceed (missing inputs, contradictory files), do not force it —
   diagnose, journal, and surface to the user.

Autonomy is **auto + interruptible**: you never pause for approval between stages, but
every stage ends with the one-line notice (`— stage <name> done · say stop to change
course · continuing —`), and the user's "stop" lands at the next atomic boundary.

## Interrupt protocol

- On "stop": complete the current atomic action (dispatch+verification or Q&A round),
  journal it, set `state.md` to paused, await instructions.
- On new input mid-mission, classify (state-machine §Interrupt semantics):
  scope change → planner re-plan · unrelated task → ask (archive / park / decline) ·
  question → answer without state change.

## New task vs scope change

If the user gives `power <new task>` while a session is active:

- The task **advances the same goal** (same deliverable, extension, refinement) →
  treat as scope change: hand to planner for re-plan; log in Decisions Log.
- The task is **a different goal** → ask: archive the current session (wrap if ready),
  park it, or start fresh alongside? Never interleave two missions in one workspace.

## Wrap & archive

When executor finishes (no ready tasks remain):

1. Run the completeness checklist (`references/state-machine.md` §Wrap).
2. Produce the mission report and show it to the user.
3. **Ask for approval — the pipeline's only hard gate.**
4. On approval: run §Archive procedure. On objections: log them, loop back into the
   relevant stage.

## Status report

Print the format from `references/state-machine.md` §Status report. No active session
→ say so, list archived sessions (`.power/sessions/`), offer to start one.

## Failure handling

- Stage skill missing or unreadable → say which file, stop cleanly with state journaled.
- `contract-version` mismatch in an existing workspace → warn, ask, never migrate silently.
- Loop-backs exceed 3 per mission → stop and consult the user.
- Any doubt about file ownership → `references/contract.md` ownership table is final.

## File map (what you may write)

`.power/active/state.md` · `.power/README.md` · root `worklog.md` (append) ·
mission.md Decisions Log rows (via grill/planner handoffs). Everything else belongs
to stage skills. `sessions/` is never written after archive.
