# Playbook: software-build

> For missions whose deliverable is running code: apps, sites, scripts, tools,
> data pipelines. Chosen when task verbs cluster around build/implement/create/configure
> and acceptance criteria reference files, endpoints, or running behavior.

## Phase structure

| # | Phase | Typical tasks | Entry criteria | Verification focus |
|---|---|---|---|---|
| 1 | Scaffold | project structure, deps, config, schemas | tasks.md ready | structure exists; deps install; config valid |
| 2 | Implement | one task per feature/component | scaffold done | per-task acceptance (behavior exists) |
| 3 | Integrate | wire components together, data flow | features done | end-to-end path works on real input |
| 4 | Test | run/extend tests, edge cases from mission | integration done | test evidence in worklog; mission's risk items covered |
| 5 | Polish | error states, docs (per mission G6), cleanup | tests pass | UX surfaces coherent; no stubs left |
| 6 | Deliver | final artifact in download/ (if packaged), README | polish done | deliverable path verifiable; wrap-ready |

## Phase-specific discipline

- **Scaffold**: boring and proven over clever (tech picks per mission constraints).
  A scaffold task's acceptance is "structure + deps + config" — verify by running the
  project's start/lint command, not by eyeballing files.
- **Implement**: the executor's sequential loop shines here — one feature per dispatch,
  verified in isolation. Guard from the classic trap: a task whose acceptance needs
  two features at once should have been split at planning time; if you meet one,
  treat it as a plan-gap signal, don't silently broaden the dispatch.
- **Integrate**: integration bugs live at the SEAMS. Verification here must use REAL
  data flowing THROUGH components, not per-component unit checks.
- **Test**: mission.md G5 sets the bar ("works when I try it" → manual script +
  evidence; "automated tests" → suite + output log as evidence).
- **Deliver**: packaged artifacts (zips, docs) go to the deliverables directory;
  the code itself stays in the workspace unless the mission says otherwise.

## Checkpoint schedule

- After EVERY task: worklog entry + tasks.md status + state.md `now/next` (this is
  contract-level, never skipped).
- At phase boundaries: extra state.md care — `next` names the next phase's first task;
  a one-line phase summary goes in the worklog Stage Summary.

## Dispatch notes

- One dispatch per task (default); `batch: true` micro-tasks (e.g., "add three config
  keys") may share one dispatch — the batch shares one verification with per-criterion
  evidence.
- Subagents should use the harness's web-app development capability for web-app work;
  document generation tasks (README exports etc.) may use its document capabilities.
  Name the capability in the dispatch prompt's CONTEXT section (contract.md §Host
  capabilities).
- Constraint reminders worth repeating in dispatch prompts: stack locks (D2),
  do-not-touch lists (D3), offline requirements (D6).

## Common pitfalls (from the field)

- Huge diffs in one dispatch → verification becomes judgment-call theater. Keep
  dispatches scoped to one task's acceptance.
- "Works on my sample" — integration verified only with fabricated input. Test the
  mission's real data shape.
- Silent scope creep inside implement tasks ("while I'm here I also…"). The dispatch
  prompt's TASK section is the boundary.
