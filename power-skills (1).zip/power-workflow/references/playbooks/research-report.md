# Playbook: research-report

> For missions whose deliverable is a synthesized document: market reports, analyses,
> briefs, white papers, literature reviews. Chosen when task verbs cluster around
> gather/analyze/draft/write and acceptance criteria reference document sections,
> sourced claims, or formats (PDF/docx/slides).

## Phase structure

| # | Phase | Typical tasks | Entry criteria | Verification focus |
|---|---|---|---|---|
| 1 | Gather | collect material per section/topic | tasks.md ready | every source saved with URL + access date |
| 2 | Verify sources | check credibility, freshness, consistency | material collected | each claim's source graded; stale facts flagged |
| 3 | Synthesize | outline → argument structure → key tables/figures | sources verified | outline covers every Done-Definition item |
| 4 | Draft | write sections (one task per section or two) | outline agreed by structure | sections exist, match outline, use verified facts only |
| 5 | Fact-check | every number/claim traced to source | draft complete | claim↔source table complete; discrepancies fixed |
| 6 | Format & deliver | produce final file(s) in download/, cover/TOC if long | fact-check clean | deliverable opens correctly; formats render; paths verifiable |

## Phase-specific discipline

- **Gather**: scout's research.md is the seed, but report missions usually need more
  depth per section. Gather tasks collect INTO the workspace (notes files under
  `.power/active/context/`) with sources — never straight into prose.
- **Verify sources**: the quality bar comes from mission grill H8 (primary-only vs
  reputable-secondary). Date-stamp anything that decays. Two sources disagreeing is a
  finding, not an error — record both and pick with a stated reason.
- **Synthesize**: the outline is the argument, not a topic list. Each section states
  what it establishes. The outline task is where report missions succeed or fail —
  don't rush it into drafting.
- **Draft**: one dispatch per section keeps quality auditable. Sections cite from the
  claim↔source table; nothing "from memory".
- **Fact-check**: mechanical and unglamorous — every number, date, and name in the
  draft traced to a source row. This phase is the difference between a report and a
  plausible-looking liability.
- **Format & deliver**: document generation via the harness's document capability
  (docx/pdf/slides or equivalent). Final files → the deliverables directory. Verify
  the artifact OPENS (render check), not just that bytes exist.

## Checkpoint schedule

- After EVERY task: worklog + tasks.md status + state.md (contract-level).
- At outline approval (phase 3): one-line note of the structure in state.md `now` —
  cold agents resuming mid-draft need the outline to orient.

## Dispatch notes

- One dispatch per section draft (default). `batch: true` for small sections may
  group — but drafting quality usually suffers past ~2 sections per dispatch.
- Dispatch prompts must name the harness capability for format-phase tasks (document
  generation) and for gather tasks (web search + page reader) — contract.md §Host
  capabilities.
- Constraint reminders: tone/voice refs (grill H6), language rule, length targets
  from mission constraints.

## Common pitfalls (from the field)

- Drafting before synthesize → 4,000 words of well-sourced mush with no argument.
  The outline IS the mission's spine.
- Unverifiable claims ("market is growing rapidly") — if fact-check can't trace it,
  cut it or source it.
- Formatting tasks discovering content problems ("this section is too long for the
  template") — content fixes go BACK to a draft task, never silently edited during
  formatting.
